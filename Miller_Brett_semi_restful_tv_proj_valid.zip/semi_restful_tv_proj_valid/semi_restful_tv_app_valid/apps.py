from django.apps import AppConfig


class SemiRestfulTvAppValidConfig(AppConfig):
    name = 'semi_restful_tv_app_valid'
